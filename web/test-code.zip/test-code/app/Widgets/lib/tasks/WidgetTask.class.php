<?php

/**
 * Widget Task
 *
 * This is a regulary run task.
 */
class WidgetTask extends BaseTask {
	public function run() {
		
	}
}
