/*
	If you want to create any database tables, please put the CREATE queries in
	this file
*/

