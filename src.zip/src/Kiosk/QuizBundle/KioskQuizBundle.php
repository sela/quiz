<?php
namespace Kiosk\QuizBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class KioskQuizBundle extends Bundle {

}



