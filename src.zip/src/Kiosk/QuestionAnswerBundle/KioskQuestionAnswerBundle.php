<?php
namespace Kiosk\QuestionAnswerBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class KioskQuestionAnswerBundle extends Bundle {

}



