<?php

namespace Kiosk\QuestionAnswerBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class EndControllerTest extends WebTestCase
{
}
